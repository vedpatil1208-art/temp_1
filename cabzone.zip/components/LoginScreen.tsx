import React, { useState } from 'react';
import Button from './Button';
import { User } from '../types';
import { Zap, ArrowRight, Mail, Phone, MapPin, User as UserIcon } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    city: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      onLogin({ 
          email: formData.email || 'user@example.com', 
          name: formData.name || 'Traveler' 
      });
      setLoading(false);
    }, 1200);
  };

  const handleChange = (field: string, value: string) => {
      setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="flex flex-col h-full bg-brand-black text-white relative overflow-hidden">
      {/* Dynamic Background Animation */}
      <div className="absolute -top-40 -right-40 w-[500px] h-[500px] bg-brand-primary/30 rounded-full blur-[100px] animate-pulse-slow"></div>
      <div className="absolute top-60 -left-20 w-80 h-80 bg-brand-accent/20 rounded-full blur-[80px] opacity-40 animate-float"></div>
      <div className="absolute bottom-0 right-0 w-full h-1/2 bg-gradient-to-t from-brand-black via-brand-black/80 to-transparent z-0"></div>

      <div className="flex-1 flex flex-col justify-center px-8 z-10 relative overflow-y-auto no-scrollbar py-8">
        
        {/* Brand Header */}
        <div className="mb-8 animate-slide-up">
            <div className="inline-flex items-center justify-center p-3 bg-gradient-to-tr from-brand-primary to-brand-accent rounded-2xl shadow-lg shadow-brand-primary/30 rotate-3 mb-6">
                <Zap className="w-8 h-8 text-white fill-white" />
            </div>
            <h1 className="text-4xl font-bold mb-2 tracking-tighter text-white">
              Join <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-accent">Cabzone</span>
            </h1>
            <p className="text-gray-400 text-sm">The future of urban mobility starts here.</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          
          <div className="group">
              <div className="glass-dark rounded-xl p-1 transition-all group-focus-within:border-brand-primary/50 border border-white/10 flex items-center">
                <div className="p-3 text-gray-400 group-focus-within:text-brand-primary transition-colors">
                    <UserIcon className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  className="w-full p-3 bg-transparent text-white placeholder-gray-500 focus:outline-none text-sm font-medium"
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  required
                />
              </div>
          </div>

          <div className="group">
              <div className="glass-dark rounded-xl p-1 transition-all group-focus-within:border-brand-primary/50 border border-white/10 flex items-center">
                <div className="p-3 text-gray-400 group-focus-within:text-brand-primary transition-colors">
                    <Mail className="w-5 h-5" />
                </div>
                <input
                  type="email"
                  className="w-full p-3 bg-transparent text-white placeholder-gray-500 focus:outline-none text-sm font-medium"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  required
                />
              </div>
          </div>

          <div className="group">
              <div className="glass-dark rounded-xl p-1 transition-all group-focus-within:border-brand-primary/50 border border-white/10 flex items-center">
                <div className="p-3 text-gray-400 group-focus-within:text-brand-primary transition-colors">
                    <Phone className="w-5 h-5" />
                </div>
                <input
                  type="tel"
                  className="w-full p-3 bg-transparent text-white placeholder-gray-500 focus:outline-none text-sm font-medium"
                  placeholder="Mobile Number"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  required
                />
              </div>
          </div>

          <div className="group">
              <div className="glass-dark rounded-xl p-1 transition-all group-focus-within:border-brand-primary/50 border border-white/10 flex items-center">
                <div className="p-3 text-gray-400 group-focus-within:text-brand-primary transition-colors">
                    <MapPin className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  className="w-full p-3 bg-transparent text-white placeholder-gray-500 focus:outline-none text-sm font-medium"
                  placeholder="City"
                  value={formData.city}
                  onChange={(e) => handleChange('city', e.target.value)}
                />
              </div>
          </div>
          
          <div className="pt-4">
              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-white text-brand-black py-4 rounded-xl font-bold text-lg hover:bg-gray-100 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.2)]"
              >
                {loading ? (
                    <span className="w-5 h-5 border-2 border-brand-black border-t-transparent rounded-full animate-spin"></span>
                ) : (
                    <>
                     Start Riding <ArrowRight className="w-5 h-5" />
                    </>
                )}
              </button>
          </div>
        </form>
      </div>
      
      <div className="p-6 text-center z-10 relative">
          <p className="text-[10px] text-gray-500">
            By signing up, you agree to our Terms of Service and Privacy Policy.
          </p>
      </div>
    </div>
  );
};

export default LoginScreen;