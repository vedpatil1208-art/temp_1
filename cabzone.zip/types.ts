export type AppScreen = 'login' | 'location' | 'car' | 'payment' | 'tracking';

export interface LocationData {
  name: string;
  address: string;
  lat?: number;
  lng?: number;
}

export enum CarTier {
  Economy = 'Economy', // Auto
  Comfort = 'Comfort', // Standard Car
  Premium = 'Premium', // Luxury
}

export interface CarOption {
  id: string;
  tier: CarTier;
  name: string;
  price: number;
  eta: number; // minutes
  image: string;
  capacity: number;
}

export interface TripDetails {
  pickup: LocationData | null;
  dropoff: LocationData | null;
  selectedCar: CarOption | null;
}

export interface User {
  email: string;
  name: string;
}