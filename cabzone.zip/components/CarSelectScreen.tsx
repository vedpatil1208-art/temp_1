import React, { useState } from 'react';
import { CarOption, CarTier, TripDetails } from '../types';
import Button from './Button';
import { Users, ArrowLeft, Clock, Zap, Home } from 'lucide-react';
import MapBackground from './MapBackground';

interface CarSelectScreenProps {
  tripDetails: TripDetails;
  onCarSelect: (car: CarOption) => void;
  onBack: () => void;
  onHome: () => void;
}

const CAR_OPTIONS: CarOption[] = [
  {
    id: '1',
    tier: CarTier.Economy,
    name: 'Auto',
    price: 8.50,
    eta: 3,
    // Creative 3D-style Auto/TukTuk
    image: 'https://cdn-icons-png.flaticon.com/512/5695/5695738.png',
    capacity: 3
  },
  {
    id: '2',
    tier: CarTier.Comfort,
    name: 'Cabzone Go',
    price: 16.20,
    eta: 5,
    // Modern 3D-style White Car
    image: 'https://cdn-icons-png.flaticon.com/512/2554/2554917.png',
    capacity: 4
  },
  {
    id: '3',
    tier: CarTier.Premium,
    name: 'Premium',
    price: 35.00,
    eta: 9,
    // Sporty/Luxury 3D-style Car
    image: 'https://cdn-icons-png.flaticon.com/512/2554/2554936.png',
    capacity: 4
  }
];

const CarSelectScreen: React.FC<CarSelectScreenProps> = ({ tripDetails, onCarSelect, onBack, onHome }) => {
  const [selectedCarId, setSelectedCarId] = useState<string>(CAR_OPTIONS[1].id);

  const handleConfirm = () => {
    const car = CAR_OPTIONS.find(c => c.id === selectedCarId);
    if (car) onCarSelect(car);
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Map visualization area (Top) */}
      <div className="flex-1 relative">
         <MapBackground active={true} locationQuery={tripDetails.dropoff?.name} />
         
         <div className="absolute top-6 left-4 z-10 flex gap-2">
            <button onClick={onBack} className="bg-white/90 backdrop-blur p-3 rounded-full shadow-lg hover:scale-105 transition-transform active:scale-95">
                <ArrowLeft className="w-5 h-5 text-black" />
            </button>
         </div>

         <div className="absolute top-6 right-4 z-10">
            <button onClick={onHome} className="bg-brand-black/90 backdrop-blur p-3 rounded-full shadow-lg hover:scale-105 transition-transform active:scale-95">
                <Home className="w-5 h-5 text-white" />
            </button>
         </div>

         {/* Abstract route indicator overlay */}
         <div className="absolute inset-0 pointer-events-none">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                 <div className="flex flex-col items-center">
                    <div className="glass px-4 py-2 rounded-full shadow-lg text-xs font-bold text-brand-black animate-float mb-2">
                        {tripDetails.dropoff?.name}
                    </div>
                    <div className="w-4 h-4 bg-brand-primary border-2 border-white rounded-full shadow-md"></div>
                    <div className="w-0.5 h-12 bg-gradient-to-b from-brand-primary to-transparent"></div>
                 </div>
             </div>
         </div>
      </div>

      {/* Car Selection Sheet */}
      <div className="bg-white rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.1)] z-20 flex flex-col animate-slide-up">
        <div className="w-12 h-1 bg-gray-200 rounded-full mx-auto mt-4 mb-4"></div>
        
        <div className="px-6 pb-4">
             <h3 className="font-bold text-xl text-gray-900">Select Ride</h3>
        </div>

        <div className="overflow-y-auto px-4 no-scrollbar max-h-[300px]">
            {CAR_OPTIONS.map((car) => {
                const isSelected = selectedCarId === car.id;
                return (
                    <div 
                        key={car.id}
                        onClick={() => setSelectedCarId(car.id)}
                        className={`relative flex items-center p-4 mb-3 rounded-2xl border-2 transition-all cursor-pointer group ${
                            isSelected 
                            ? 'border-brand-black bg-gray-50 shadow-md transform scale-[1.02]' 
                            : 'border-transparent hover:bg-gray-50'
                        }`}
                    >
                        {isSelected && (
                            <div className="absolute -right-1 -top-1 bg-brand-black text-white text-[10px] font-bold px-2 py-0.5 rounded-full z-10">
                                SELECTED
                            </div>
                        )}

                        {/* Car Image with creative animation */}
                        <div className={`w-20 h-16 mr-4 relative flex items-center justify-center transition-all duration-500 ${isSelected ? 'animate-float' : ''}`}>
                             {/* Shadow for depth */}
                             <div className="absolute bottom-1 left-2 right-2 h-2 bg-black/20 blur-md rounded-full transform scale-x-75"></div>
                            <img 
                                src={car.image} 
                                alt={car.name} 
                                className="w-full h-full object-contain drop-shadow-lg relative z-10" 
                            />
                        </div>

                        <div className="flex-1">
                            <div className="flex items-center gap-2 mb-0.5">
                                <span className="font-bold text-lg text-gray-900">{car.name}</span>
                                <div className="flex items-center text-xs bg-gray-200 px-1.5 py-0.5 rounded text-gray-700 font-medium">
                                    <Users className="w-3 h-3 mr-0.5" />
                                    {car.capacity}
                                </div>
                            </div>
                            <div className="text-xs text-gray-500 flex items-center gap-2">
                                <span className="flex items-center text-green-600 font-medium">
                                    <Clock className="w-3 h-3 mr-0.5" /> {car.eta} min
                                </span>
                                 • {new Date(Date.now() + car.eta * 60000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                        </div>

                        <div className="text-right">
                            <div className="font-bold text-lg text-brand-primary">${car.price.toFixed(2)}</div>
                        </div>
                    </div>
                );
            })}
        </div>

        <div className="p-6 border-t border-gray-50 bg-white pb-8 shadow-[0_-5px_20px_rgba(0,0,0,0.05)] rounded-t-[32px]">
            <Button onClick={handleConfirm} fullWidth className="!rounded-2xl !py-4 text-lg shadow-brand-primary/20 hover:shadow-brand-primary/40 transition-shadow">
                Proceed to Payment
            </Button>
        </div>
      </div>
    </div>
  );
};

export default CarSelectScreen;