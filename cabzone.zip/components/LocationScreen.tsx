import React, { useState, useEffect, useRef } from 'react';
import { LocationData } from '../types';
import Button from './Button';
import { searchPlaces } from '../services/geminiService';
import { MapPin, Navigation, Star, Coffee, Moon, Utensils, Sparkles } from 'lucide-react';
import MapBackground from './MapBackground';

interface LocationScreenProps {
  onLocationSelect: (pickup: LocationData, dropoff: LocationData) => void;
}

const LocationScreen: React.FC<LocationScreenProps> = ({ onLocationSelect }) => {
  const [pickup, setPickup] = useState<LocationData | null>({ name: "Current Location", address: "Near you" });
  const [dropoffQuery, setDropoffQuery] = useState('');
  const [suggestions, setSuggestions] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Use suggestions[0] as the map background context if available, otherwise pickup
  const activeMapLocation = suggestions.length > 0 ? suggestions[0].name : (pickup?.name || "San Francisco");

  const vibes = [
    { label: "Coffee", icon: <Coffee className="w-3 h-3" />, query: "Best rated coffee shops nearby" },
    { label: "Foodie", icon: <Utensils className="w-3 h-3" />, query: "Trending restaurants nearby" },
    { label: "Nightlife", icon: <Moon className="w-3 h-3" />, query: "Popular bars and clubs" },
    { label: "Surprise Me", icon: <Sparkles className="w-3 h-3" />, query: "Hidden gems and unique spots nearby" },
  ];

  useEffect(() => {
    if (dropoffQuery.length > 2) {
      triggerSearch(dropoffQuery);
    } else {
      setSuggestions([]);
    }
  }, [dropoffQuery]);

  const triggerSearch = (query: string) => {
    setIsSearching(true);
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    
    debounceTimer.current = setTimeout(async () => {
      const results = await searchPlaces(query);
      setSuggestions(results);
      setIsSearching(false);
    }, 600);
  };

  const handleVibeClick = (vibeQuery: string, vibeLabel: string) => {
      setDropoffQuery(vibeLabel); // Show label in input for aesthetics
      triggerSearch(vibeQuery);
  };

  const handleSelect = (location: LocationData) => {
    if (pickup) {
      onLocationSelect(pickup, location);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Background Map Visual */}
      <div className="h-[35%] relative w-full overflow-hidden group">
        <MapBackground active={true} locationQuery={activeMapLocation} />
        
        <Button 
            className="absolute top-4 left-4 z-10 !p-3 !rounded-full bg-white/80 backdrop-blur-md shadow-lg text-black border border-white/20"
            variant="secondary"
            onClick={() => {}}
        >
            <Navigation className="w-5 h-5 transform rotate-180" />
        </Button>
        
        <div className="absolute bottom-10 left-6 z-10">
             <h2 className="text-2xl font-bold text-gray-800 shadow-white drop-shadow-md">Good Morning, Alex.</h2>
             <p className="text-gray-600 font-medium">Where to today?</p>
        </div>
      </div>

      <div className="flex-1 bg-white -mt-6 rounded-t-[32px] shadow-[0_-10px_30px_rgba(0,0,0,0.05)] relative z-20 p-6 flex flex-col animate-slide-up">
        
        <div className="space-y-4 relative mb-6">
            {/* Connector Line */}
            <div className="absolute left-[19px] top-10 bottom-10 w-0.5 bg-gradient-to-b from-gray-300 to-brand-primary/50 border-l border-dashed border-gray-400"></div>

            {/* Pickup Input */}
            <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gray-50 border border-gray-100 flex items-center justify-center shrink-0 z-10 shadow-sm">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                </div>
                <div className="flex-1 p-3.5 bg-gray-50/50 rounded-2xl border border-transparent focus-within:border-gray-200 focus-within:bg-white transition-all">
                    <div className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-0.5">From</div>
                    <input 
                        type="text" 
                        value={pickup?.name}
                        onChange={(e) => setPickup({ name: e.target.value, address: '' })}
                        className="w-full bg-transparent outline-none font-semibold text-gray-700 text-sm"
                    />
                </div>
            </div>

            {/* Dropoff Input */}
            <div className="flex items-center gap-4">
                 <div className="w-10 h-10 rounded-full bg-brand-primary/10 flex items-center justify-center shrink-0 z-10 shadow-sm">
                    <div className="w-2 h-2 bg-brand-primary rounded-sm"></div>
                </div>
                 <div className="flex-1 p-3.5 bg-white rounded-2xl border border-brand-primary/20 focus-within:border-brand-primary focus-within:ring-4 focus-within:ring-brand-primary/5 transition-all shadow-lg shadow-brand-primary/5">
                    <div className="text-[10px] text-brand-primary font-bold uppercase tracking-wider mb-0.5">To</div>
                    <input 
                        type="text" 
                        value={dropoffQuery}
                        onChange={(e) => setDropoffQuery(e.target.value)}
                        placeholder="Try 'Best Tacos' or 'Gym'..."
                        className="w-full bg-transparent outline-none font-bold text-gray-900 placeholder-gray-300"
                        autoFocus
                    />
                </div>
            </div>
        </div>

        {/* Vibe Chips */}
        <div className="flex gap-3 mb-6 overflow-x-auto no-scrollbar pb-2">
            {vibes.map((vibe) => (
                <button 
                    key={vibe.label}
                    onClick={() => handleVibeClick(vibe.query, vibe.label)}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-50 border border-gray-100 whitespace-nowrap hover:bg-brand-primary hover:text-white hover:border-transparent transition-all text-sm font-medium text-gray-600 shadow-sm"
                >
                    {vibe.icon}
                    {vibe.label}
                </button>
            ))}
        </div>

        {/* Suggestions List */}
        <div className="flex-1 overflow-y-auto no-scrollbar -mx-2 px-2">
            {isSearching ? (
                <div className="flex flex-col items-center justify-center py-8 opacity-50">
                    <div className="animate-spin rounded-full h-6 w-6 border-2 border-brand-primary border-t-transparent"></div>
                    <p className="text-xs mt-2 text-gray-400">Asking the AI...</p>
                </div>
            ) : suggestions.length > 0 ? (
                <div className="space-y-3">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wide px-1">Results</h3>
                    {suggestions.map((loc, idx) => (
                        <div 
                            key={idx}
                            onClick={() => handleSelect(loc)}
                            className="flex items-center gap-4 p-3 hover:bg-gray-50 rounded-xl cursor-pointer transition-all border border-transparent hover:border-gray-100 hover:shadow-sm group"
                        >
                            <div className="p-2.5 bg-gray-100 rounded-full text-gray-500 group-hover:bg-brand-primary group-hover:text-white transition-colors">
                                <MapPin className="w-5 h-5" />
                            </div>
                            <div>
                                <div className="font-bold text-gray-900">{loc.name}</div>
                                <div className="text-xs text-gray-500 truncate">{loc.address}</div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="space-y-3">
                     <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wide px-1">Saved</h3>
                     <div onClick={() => handleSelect({ name: 'Home', address: 'My Address' })} className="flex items-center gap-4 p-3 bg-brand-primary/5 rounded-xl cursor-pointer border border-transparent hover:border-brand-primary/20 transition-all">
                        <div className="p-2 bg-white rounded-full text-brand-primary shadow-sm">
                            <Star className="w-4 h-4 fill-current" />
                        </div>
                        <div>
                            <div className="font-bold text-gray-900">Home</div>
                            <div className="text-xs text-gray-500">500 Main Street</div>
                        </div>
                     </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default LocationScreen;