import React, { useState, useEffect } from 'react';
import { TripDetails } from '../types';
import MapBackground from './MapBackground';
import { Phone, MessageSquare, Shield, X, Star, MapPin, Sparkles } from 'lucide-react';
import { generateDriverMessage, getDestinationTrivia } from '../services/geminiService';

interface TrackingScreenProps {
  tripDetails: TripDetails;
  onCancel: () => void;
}

const TrackingScreen: React.FC<TrackingScreenProps> = ({ tripDetails, onCancel }) => {
  const [eta, setEta] = useState(tripDetails.selectedCar?.eta || 5);
  const [status, setStatus] = useState("Looking for drivers...");
  const [driverName, setDriverName] = useState<string | null>(null);
  const [chatMessage, setChatMessage] = useState<string | null>(null);
  const [trivia, setTrivia] = useState<string | null>(null);
  const [showTrivia, setShowTrivia] = useState(false);
  // Map view: starts at pickup, switches to dropoff when ride starts
  const [currentMapLocation, setCurrentMapLocation] = useState(tripDetails.pickup?.name || "San Francisco");

  // Simulate Trip Lifecycle
  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];

    // Step 1: Found Driver
    timers.push(setTimeout(() => {
        setStatus("Driver found");
        setDriverName("Michael");
    }, 2500));

    // Step 2: Driver En Route + AI Interactions
    timers.push(setTimeout(async () => {
        setStatus("Heading to pickup");
        
        // Generate Driver Message
        const msg = await generateDriverMessage({ passengerName: 'Alex' });
        setChatMessage(msg);

        // Generate Trip Trivia
        if (tripDetails.dropoff?.name) {
            const fact = await getDestinationTrivia(tripDetails.dropoff.name);
            setTrivia(fact);
            setShowTrivia(true);
            // Switch map to destination so user sees where they are going
            setCurrentMapLocation(tripDetails.dropoff.name);
        }
    }, 4500));

    // Step 3: Countdown
    const interval = setInterval(() => {
        setEta((prev) => Math.max(0, prev - 1));
    }, 60000);

    return () => {
        timers.forEach(t => clearTimeout(t));
        clearInterval(interval);
    };
  }, [tripDetails.dropoff, tripDetails.pickup]);

  return (
    <div className="flex flex-col h-full relative overflow-hidden bg-gray-50">
      
      {/* Interactive Map Visual with actual location */}
      <div className="absolute inset-0 z-0">
         <MapBackground active={true} locationQuery={currentMapLocation} />
         
         {/* Simulated Car Overlay centered on map */}
         <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none">
            <div className="w-20 h-20 bg-brand-primary/10 rounded-full animate-ping absolute inset-0"></div>
            <div className="relative bg-black border-2 border-white rounded-full w-10 h-10 flex items-center justify-center shadow-xl z-20">
                 <div className="w-full h-full bg-black rounded-full flex items-center justify-center text-white">
                    <div className="w-1.5 h-4 bg-white rounded-sm"></div>
                 </div>
            </div>
             <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black/70 text-white text-[10px] px-2 py-1 rounded-lg backdrop-blur-md">
                 {status.includes("Heading to") ? "En Route" : "Connecting..."}
             </div>
         </div>
      </div>

      {/* Top Dynamic Island Status */}
      <div className="absolute top-4 left-4 right-4 z-20">
        <div className="glass-dark text-white p-1 rounded-full shadow-2xl flex items-center justify-between animate-slide-up-fast pr-4">
             <div className="flex items-center gap-3 bg-brand-black rounded-full py-2 px-4">
                 <span className="font-bold text-lg text-green-400">{eta}</span>
                 <span className="text-[10px] uppercase font-bold tracking-wider text-gray-400">min</span>
             </div>
             <span className="text-sm font-medium truncate ml-2 animate-pulse">{status}</span>
        </div>
      </div>
      
      {/* AI Companion Trivia Card (Floats above driver sheet) */}
      {showTrivia && trivia && (
          <div className="absolute bottom-[320px] left-4 right-4 z-20 animate-float">
              <div className="glass p-4 rounded-2xl shadow-lg border-l-4 border-brand-accent">
                  <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-brand-accent fill-brand-accent" />
                      <span className="text-xs font-bold text-brand-accent uppercase">Cabzone Companion</span>
                  </div>
                  <p className="text-sm text-gray-800 font-medium leading-relaxed">
                      "{trivia}"
                  </p>
              </div>
          </div>
      )}

      {/* Bottom Driver Sheet */}
      <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.15)] z-30 animate-slide-up p-6 pb-8">
        
        {/* Header Info */}
        <div className="flex justify-between items-center mb-6">
            <div>
                 <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Destination</div>
                 <div className="text-lg font-bold text-gray-900 flex items-center gap-1">
                    <MapPin className="w-4 h-4 text-brand-black" />
                    <span className="truncate max-w-[200px]">{tripDetails.dropoff?.name}</span>
                 </div>
            </div>
            <div className="text-right">
                <div className="bg-gray-100 text-gray-600 px-2 py-1 rounded-lg text-xs font-bold">
                    {tripDetails.selectedCar?.name}
                </div>
            </div>
        </div>

        {/* Driver Card */}
        <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl mb-6 border border-gray-100 relative overflow-hidden">
             <div className="absolute right-0 top-0 w-24 h-24 bg-brand-primary/5 rounded-full -mr-8 -mt-8"></div>
             
             <div className="relative">
                <div className="w-14 h-14 bg-gray-300 rounded-full overflow-hidden border-2 border-white shadow-md">
                    <img src="https://picsum.photos/200" alt="Driver" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow">
                     <div className="bg-green-500 w-3 h-3 rounded-full border-2 border-white"></div>
                </div>
            </div>
            
            <div className="flex-1">
                <div className="font-bold text-lg text-gray-900">{driverName || 'Finding...'}</div>
                <div className="flex items-center gap-2">
                    <div className="flex items-center text-orange-500 text-xs font-bold bg-orange-50 px-1.5 py-0.5 rounded">
                        <Star className="w-3 h-3 fill-current mr-1" />
                        4.9
                    </div>
                    <span className="text-gray-400 text-xs">• 7X9 22A</span>
                </div>
            </div>

            <div className="text-right">
                 <div className="w-16 relative">
                    <img src={tripDetails.selectedCar?.image} alt="Car" className="w-full object-contain mix-blend-multiply" />
                 </div>
            </div>
        </div>

        {/* Actions Grid */}
        <div className="grid grid-cols-4 gap-3 mb-6">
            <button className="flex flex-col items-center justify-center gap-2 p-2 rounded-xl hover:bg-gray-50 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center group-hover:bg-brand-primary group-hover:text-white transition-all text-gray-600 shadow-sm">
                    <MessageSquare className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-500">Chat</span>
            </button>
            <button className="flex flex-col items-center justify-center gap-2 p-2 rounded-xl hover:bg-gray-50 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center group-hover:bg-green-500 group-hover:text-white transition-all text-gray-600 shadow-sm">
                    <Phone className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-500">Call</span>
            </button>
            <button className="flex flex-col items-center justify-center gap-2 p-2 rounded-xl hover:bg-gray-50 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-all text-gray-600 shadow-sm">
                    <Shield className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-500">Safety</span>
            </button>
             <button onClick={onCancel} className="flex flex-col items-center justify-center gap-2 p-2 rounded-xl hover:bg-red-50 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center group-hover:bg-red-500 group-hover:text-white transition-all text-red-500 shadow-sm">
                    <X className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-gray-500">Cancel</span>
            </button>
        </div>

        {/* Driver Chat Message Bubble */}
        {chatMessage && (
            <div className="bg-brand-primary text-white p-3 rounded-2xl rounded-tl-none shadow-lg animate-slide-up text-sm font-medium flex items-center gap-3 relative">
                <div className="absolute -top-2 left-0 w-3 h-3 bg-brand-primary [clip-path:polygon(0%_100%,100%_100%,100%_0%)]"></div>
                <MessageSquare className="w-4 h-4 fill-white/20 text-white/50 shrink-0" />
                "{chatMessage}"
            </div>
        )}

      </div>
    </div>
  );
};

export default TrackingScreen;