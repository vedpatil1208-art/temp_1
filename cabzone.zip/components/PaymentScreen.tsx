import React, { useState } from 'react';
import { TripDetails } from '../types';
import Button from './Button';
import { CreditCard, Wallet, Banknote, CheckCircle, ArrowLeft, Lock } from 'lucide-react';

interface PaymentScreenProps {
  tripDetails: TripDetails;
  onPaymentComplete: () => void;
  onBack: () => void;
}

type PaymentMethod = 'card' | 'upi' | 'cash';

const PaymentScreen: React.FC<PaymentScreenProps> = ({ tripDetails, onPaymentComplete, onBack }) => {
  const [method, setMethod] = useState<PaymentMethod>('card');
  const [processing, setProcessing] = useState(false);

  const handlePay = () => {
    setProcessing(true);
    // Simulate payment processing
    setTimeout(() => {
      onPaymentComplete();
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full bg-brand-gray relative">
      
      {/* Header */}
      <div className="bg-white pt-6 pb-4 px-6 shadow-sm z-10">
        <div className="flex items-center gap-4 mb-4">
             <button onClick={onBack} className="p-2 rounded-full hover:bg-gray-100">
                <ArrowLeft className="w-6 h-6" />
             </button>
             <h1 className="text-2xl font-bold">Checkout</h1>
        </div>
        
        {/* Order Summary Card */}
        <div className="bg-brand-black text-white p-5 rounded-2xl shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-10 -mt-10 blur-2xl"></div>
            <div className="relative z-10">
                <div className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-1">Total to Pay</div>
                <div className="text-4xl font-bold mb-4">${tripDetails.selectedCar?.price.toFixed(2)}</div>
                
                <div className="flex justify-between items-center text-sm border-t border-white/10 pt-3">
                    <span className="text-gray-300">{tripDetails.selectedCar?.name} Ride</span>
                    <span className="text-gray-300 truncate max-w-[120px]">to {tripDetails.dropoff?.name}</span>
                </div>
            </div>
        </div>
      </div>

      <div className="flex-1 p-6 overflow-y-auto">
        <h3 className="font-bold text-gray-900 mb-4">Payment Method</h3>
        
        <div className="space-y-3">
            <div 
                onClick={() => setMethod('card')}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 cursor-pointer transition-all ${method === 'card' ? 'border-brand-primary bg-white shadow-md' : 'border-transparent bg-white shadow-sm'}`}
            >
                <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                    <CreditCard className="w-5 h-5" />
                </div>
                <div className="flex-1">
                    <div className="font-bold text-gray-900">Credit / Debit Card</div>
                    <div className="text-xs text-gray-500">Visa ending in 4242</div>
                </div>
                {method === 'card' && <div className="w-5 h-5 rounded-full bg-brand-primary flex items-center justify-center"><div className="w-2 h-2 bg-white rounded-full"></div></div>}
            </div>

            <div 
                onClick={() => setMethod('upi')}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 cursor-pointer transition-all ${method === 'upi' ? 'border-brand-primary bg-white shadow-md' : 'border-transparent bg-white shadow-sm'}`}
            >
                <div className="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                    <Wallet className="w-5 h-5" />
                </div>
                <div className="flex-1">
                    <div className="font-bold text-gray-900">UPI / Wallet</div>
                    <div className="text-xs text-gray-500">Google Pay, PhonePe</div>
                </div>
                {method === 'upi' && <div className="w-5 h-5 rounded-full bg-brand-primary flex items-center justify-center"><div className="w-2 h-2 bg-white rounded-full"></div></div>}
            </div>

            <div 
                onClick={() => setMethod('cash')}
                className={`p-4 rounded-xl border-2 flex items-center gap-4 cursor-pointer transition-all ${method === 'cash' ? 'border-brand-primary bg-white shadow-md' : 'border-transparent bg-white shadow-sm'}`}
            >
                <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center text-green-600">
                    <Banknote className="w-5 h-5" />
                </div>
                <div className="flex-1">
                    <div className="font-bold text-gray-900">Cash</div>
                    <div className="text-xs text-gray-500">Pay driver directly</div>
                </div>
                {method === 'cash' && <div className="w-5 h-5 rounded-full bg-brand-primary flex items-center justify-center"><div className="w-2 h-2 bg-white rounded-full"></div></div>}
            </div>
        </div>
      </div>

      <div className="p-6 bg-white border-t border-gray-100 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
         <div className="flex items-center justify-center gap-2 text-xs text-gray-400 mb-4">
            <Lock className="w-3 h-3" />
            <span>Payments are secure and encrypted</span>
         </div>
         <Button 
            onClick={handlePay} 
            fullWidth 
            className="!rounded-2xl !py-4 text-lg shadow-brand-primary/20 flex items-center justify-center gap-2"
            disabled={processing}
         >
            {processing ? (
                <>
                 <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                 Processing...
                </>
            ) : (
                <>Pay & Book Ride</>
            )}
         </Button>
      </div>
    </div>
  );
};

export default PaymentScreen;