import React from 'react';

interface MapBackgroundProps {
  active?: boolean;
  locationQuery?: string;
}

const MapBackground: React.FC<MapBackgroundProps> = ({ active = true, locationQuery }) => {
  // Default to a lively location if none provided (e.g., Union Square SF)
  const query = locationQuery && locationQuery !== "Current Location" ? locationQuery : "Union Square, San Francisco";
  
  // Construct the embed URL. 
  // z=14 is a good zoom level for city streets.
  // t=m is standard map, t=k is satellite. Using m for readability.
  const mapUrl = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=m&z=15&output=embed&iwloc=near`;

  return (
    <div className={`absolute inset-0 z-0 overflow-hidden bg-gray-100 transition-all duration-1000 ${active ? 'opacity-100 scale-100' : 'opacity-0 scale-105'}`}>
       <div className="absolute inset-0 bg-gray-200 animate-pulse"></div>
       
       <iframe
         title="Map View"
         width="100%"
         height="100%"
         frameBorder="0"
         src={mapUrl}
         className="w-full h-full mix-blend-multiply grayscale-[20%] contrast-[1.1] opacity-80 transition-opacity duration-500"
         style={{ border: 0 }}
         loading="lazy"
       />
       
       {/* Artistic Overlays to blend map with app design */}
       {/* Top gradient for header text visibility */}
       <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-white via-white/80 to-transparent pointer-events-none"></div>
       
       {/* Bottom gradient for sheet blending */}
       <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-white via-white/60 to-transparent pointer-events-none"></div>
       
       {/* Color tint */}
       <div className="absolute inset-0 bg-brand-primary/5 pointer-events-none mix-blend-overlay"></div>
    </div>
  );
};

export default MapBackground;