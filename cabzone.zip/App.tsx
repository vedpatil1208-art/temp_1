import React, { useState } from 'react';
import { AppScreen, TripDetails, LocationData, CarOption, User } from './types';
import LoginScreen from './components/LoginScreen';
import LocationScreen from './components/LocationScreen';
import CarSelectScreen from './components/CarSelectScreen';
import TrackingScreen from './components/TrackingScreen';
import PaymentScreen from './components/PaymentScreen';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('login');
  const [user, setUser] = useState<User | null>(null);
  const [tripDetails, setTripDetails] = useState<TripDetails>({
    pickup: null,
    dropoff: null,
    selectedCar: null,
  });

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentScreen('location');
  };

  const handleLocationSelect = (pickup: LocationData, dropoff: LocationData) => {
    setTripDetails(prev => ({ ...prev, pickup, dropoff }));
    setCurrentScreen('car');
  };

  const handleCarSelect = (car: CarOption) => {
    setTripDetails(prev => ({ ...prev, selectedCar: car }));
    // Go to payment instead of tracking immediately
    setCurrentScreen('payment');
  };

  const handlePaymentComplete = () => {
    setCurrentScreen('tracking');
  };

  const handleCancelTrip = () => {
    // Reset trip but keep user logged in
    setTripDetails({ pickup: null, dropoff: null, selectedCar: null });
    setCurrentScreen('location');
  };

  const handleGoHome = () => {
     setTripDetails({ pickup: null, dropoff: null, selectedCar: null });
     setCurrentScreen('location');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <LoginScreen onLogin={handleLogin} />;
      case 'location':
        return <LocationScreen onLocationSelect={handleLocationSelect} />;
      case 'car':
        return (
          <CarSelectScreen 
            tripDetails={tripDetails} 
            onCarSelect={handleCarSelect} 
            onBack={() => setCurrentScreen('location')}
            onHome={handleGoHome}
          />
        );
      case 'payment':
        return (
            <PaymentScreen 
                tripDetails={tripDetails}
                onPaymentComplete={handlePaymentComplete}
                onBack={() => setCurrentScreen('car')}
            />
        );
      case 'tracking':
        return <TrackingScreen tripDetails={tripDetails} onCancel={handleCancelTrip} />;
      default:
        return <div>Error: Unknown screen</div>;
    }
  };

  return (
    <div className="max-w-md mx-auto h-screen bg-white overflow-hidden shadow-2xl relative md:border-x md:border-gray-200">
      {renderScreen()}
    </div>
  );
};

export default App;