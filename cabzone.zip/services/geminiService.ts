import { GoogleGenAI } from "@google/genai";
import { LocationData } from "../types";

// Initialize Gemini client
// Note: In a real app, ensure process.env.API_KEY is defined.
const apiKey = process.env.API_KEY || '';
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const searchPlaces = async (query: string): Promise<LocationData[]> => {
  if (!ai || !query || query.length < 3) {
    // Return mock data if API key is missing or query is too short
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          { name: "Downtown Station", address: "123 Main St, Cityville" },
          { name: "City Airport", address: "Terminal 1, Int'l Airport" },
          { name: "Central Park", address: "59th St to 110th St" },
        ]);
      }, 500);
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Find precise locations for: "${query}". Return a list of plausible real-world places.`,
      config: {
        tools: [{ googleMaps: {} }],
      },
    });

    const candidates = response.candidates;
    if (!candidates || candidates.length === 0) return [];

    const groundingChunks = candidates[0].groundingMetadata?.groundingChunks;
    
    if (!groundingChunks) return [];

    const locations: LocationData[] = [];

    // Extract grounding chunks that contain map data
    for (const chunk of groundingChunks) {
      if (chunk.web?.uri && chunk.web?.title) {
         locations.push({
            name: chunk.web.title,
            address: chunk.web.uri, 
         });
      }
    }
    
    if (locations.length === 0 && response.text) {
        const lines = response.text.split('\n').filter(l => l.includes('-'));
        lines.forEach(line => {
             locations.push({ name: line.replace(/^- /, '').trim(), address: 'Suggested Place' });
        });
    }

    return locations.length > 0 ? locations : [
        { name: "AI Suggestion", address: response.text.slice(0, 50) + "..." }
    ];

  } catch (error) {
    console.error("Gemini Search Error:", error);
    return [
      { name: "Union Square", address: "333 Post St, San Francisco" },
      { name: "Ferry Building", address: "1 Ferry Bldg, San Francisco" },
    ];
  }
};

export const generateDriverMessage = async (trip: any): Promise<string> => {
    if (!ai) return "I'm on my way!";
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a short, friendly message from a ride-share driver to a passenger named ${trip.passengerName || 'there'}. The driver is 2 minutes away.`,
        });
        return response.text || "On my way!";
    } catch (e) {
        return "See you soon!";
    }
}

export const getDestinationTrivia = async (destination: string): Promise<string> => {
  if (!ai) return "Did you know? This city has over 50 parks.";
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Tell me one short, fascinating, obscure fact about ${destination} or the general area. Keep it under 25 words. Start with "Fun Fact:"`,
    });
    return response.text || "Enjoy your ride!";
  } catch (e) {
    return "Buckle up and enjoy the view!";
  }
};